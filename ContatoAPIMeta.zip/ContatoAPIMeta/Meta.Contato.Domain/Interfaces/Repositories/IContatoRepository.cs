﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Meta.Contato.Domain.Interfaces.Repositories
{
    interface IContatoRepository
    {
    }
}
