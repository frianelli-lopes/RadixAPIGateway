﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Meta.Contato.Domain.Models
{
    public class Contato
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Canal { get; set; }
        public string Valor { get; set; }
        public string Observacao { get; set; }
    }
}
