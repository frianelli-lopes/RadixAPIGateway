﻿namespace Meta.Contato.Api.Models
{
    public class Contato
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Canal { get; set; }
        public string Valor { get; set; }
        public string Obs { get; set; }
    }
}
