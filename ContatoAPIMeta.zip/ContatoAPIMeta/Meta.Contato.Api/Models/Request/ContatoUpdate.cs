﻿namespace Meta.Contato.Api.Models.Request
{
    public class ContatoUpdate : ContatoRequestBase
    {
    }
}
