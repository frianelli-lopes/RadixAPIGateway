﻿using Meta.Contato.Api.Helpers.Validators;
using System.ComponentModel.DataAnnotations;

namespace Meta.Contato.Api.Models.Request
{
    public class ContatoRequestBase
    {
        [Required(ErrorMessage = "Favor informar o nome")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Favor informar o canal")]
        [RegularExpression("(email|celular|fixo)", ErrorMessage = "Favor informar os valores email, celular ou fixo para o canal")]
        public string Canal { get; set; }

        [Required(ErrorMessage = "Favor informar o valor")]
        [ValorCanal(ErrorMessage = "Favor informar um valor válido para o tipo de canal")]
        public string Valor { get; set; }

        public string Obs { get; set; }
    }
}
