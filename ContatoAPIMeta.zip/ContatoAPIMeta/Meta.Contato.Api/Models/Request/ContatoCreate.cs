﻿namespace Meta.Contato.Api.Models.Request
{
    public class ContatoCreate : ContatoRequestBase
    {
    }
}
