﻿using AutoMapper;
using Meta.Contato.Api.Models;
using Meta.Contato.Api.Models.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Meta.Contato.Api.Controllers
{
    [Route("api/[controller]")]
    public class ContatoController : Controller
    {
        private readonly Contexto _context;
        private readonly IMapper _mapper;

        public ContatoController(Contexto context, IMapper mapper)
        {

            _context = context;
            _mapper = mapper;

            if (_context.Contatos.Count() == 0)
            {
                _context.Contatos.AddRange(GerarMassaDadosIniciais());
                _context.SaveChanges();
            }
        }

        // GET: api/<controller>
        [HttpGet]
        public IActionResult Get(int size = 10, int page = 0)
        {
            if (page == 0) page = 1;

            var lista = _context.Contatos.OrderBy(x => x.Id).Skip((page - 1) * size).Take(size).ToList();

            if (lista == null || lista.Count() == 0) return NotFound();

            return Ok(lista);
        }

        // GET api/<controller>/5
        [HttpGet("{idContato}", Name = "GetContato")]
        public IActionResult Get(int idContato)
        {
            var contato = RecuperarContato(idContato);

            if (contato == null) return NotFound();

            return Ok(contato);
        }

        // POST api/<controller>
        [HttpPost]
        public IActionResult Post([FromBody]ContatoCreate model)
        {
            if (model == null) return BadRequest();

            if (!ModelState.IsValid) return BadRequest(ModelState);

            var contato = _mapper.Map<Models.Contato>(model);
            contato.Id = RetornarProximoId();

            _context.Contatos.Add(contato);
            _context.SaveChanges();

            return CreatedAtRoute("GetContato", new { idContato = contato.Id }, contato);
        }

        // PUT api/<controller>/5
        [HttpPut("{idContato}")]
        public IActionResult Put(int idContato, [FromBody]ContatoUpdate model)
        {
            if (model == null) return BadRequest();

            if (!ModelState.IsValid) return BadRequest(ModelState);

            if (!ContatoExiste(idContato)) return NotFound();

            var contato = _mapper.Map<Models.Contato>(model);
            contato.Id = idContato;

            _context.Contatos.Update(contato);
            _context.SaveChanges();

            return NoContent();
        }

        // DELETE api/<controller>/5
        [HttpDelete("{idContato}")]
        public IActionResult Delete(int idContato)
        {
            var contato = RecuperarContato(idContato);

            if (contato == null) return NotFound();

            _context.Contatos.Remove(contato);
            _context.SaveChanges();

            return NoContent();
        }

        #region Métodos de Apoio

        private int RetornarProximoId()
        {
            if (_context.Contatos.Count() == 0) return 1;

            return _context.Contatos.Select(x => x.Id).Max() + 1;
        }

        private bool ContatoExiste(int idContato)
        {
            return _context.Contatos.Any(x => x.Id == idContato);
        }

        private Models.Contato RecuperarContato(int idContato)
        {
            return _context.Contatos.Find(idContato);
        }

        private List<Models.Contato> GerarMassaDadosIniciais()
        {
            List<Models.Contato> contatosIniciais = new List<Models.Contato>();
            string canal, valor;

            for (int i = 1; i <= 50; i++)
            {
                switch (i % 3)
                {
                    case 0:
                        canal = "email";
                        valor = $"contato{i}@gmail.com";
                        break;

                    case 1:
                        canal = "celular";
                        valor = "99999-9999";
                        break;

                    default:
                        canal = "fixo";
                        valor = "1111-1111";
                        break;

                }
                contatosIniciais.Add(new Models.Contato() { Id = i, Nome = $"Contato { i }", Canal = canal, Valor = valor, Obs = $"Observação {i}" });
            }

            return contatosIniciais;
        }

        #endregion

    }
}
