﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Meta.Contato.Api.Helpers.AutoMapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Models.Contato, Models.Request.ContatoCreate>().ReverseMap();
            CreateMap<Models.Contato, Models.Request.ContatoUpdate>().ReverseMap();
        }
    }
}
