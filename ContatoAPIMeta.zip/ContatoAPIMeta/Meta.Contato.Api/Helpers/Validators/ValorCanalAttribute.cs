﻿using Meta.Contato.Api.Models.Request;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace Meta.Contato.Api.Helpers.Validators
{
    public class ValorCanalAttribute : ValidationAttribute
    {
        public ValorCanalAttribute() : base("Valor inválido para o tipo de canal informado")
        {
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            ContatoRequestBase contato = (ContatoRequestBase)validationContext.ObjectInstance;

            if (string.IsNullOrWhiteSpace(contato.Canal) || string.IsNullOrWhiteSpace(contato.Valor)) return ValidationResult.Success;


            string expressaoValidacao=string.Empty;
            string complemento = string.Empty;

            switch (contato.Canal.ToUpper())
            {
                case "EMAIL":
                    expressaoValidacao = @"^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])$";
                    break;

                case "CELULAR":
                    expressaoValidacao = @"^\d{5}\-\d{4}$";
                    complemento = "Formato (99999-9999)";
                    break;

                case "FIXO":
                    expressaoValidacao = @"^\d{4}\-\d{4}$";
                    complemento = "Formato (9999-9999)";
                    break;
            }

            if (!Regex.IsMatch(contato.Valor, expressaoValidacao)) return new ValidationResult($"Valor inválido para o tipo de canal informado. {complemento}");

            return ValidationResult.Success;
        }
    }
}
